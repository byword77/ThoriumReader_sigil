(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,79943,o=>{"use strict";let a=`/* Readium CSS
   EBPAJ Fonts Patch module

   A stylesheet improving EBPAJ @font-face declarations to cover all platforms

   Repo: https://github.com/readium/css */

/* EBPAJ template only references fonts from MS Windows…
   so we must reference fonts from other platforms
   and override authors’ stylesheets.
   What we do there is keeping their default value and providing fallbacks.

   /!\\ /!\\ /!\\ /!\\ /!\\
   FYI, you might want to load this polyfill only if you find
   one of the following metadata items in the OPF package:
   - version 1:
     <dc:description id="ebpaj-guide">ebpaj-guide-1.0</dc:description>
   - version 1.1:
     <meta property="ebpaj:guide-version">1.1</meta>
*/

/* 
   Hiragino PostScript Font name lists:
   https://www.screen.co.jp/ga_product/sento/support/QA/ss_psname.html
*/

/* 横組み用 (horizontal writing) */

@font-face {
  font-family: "serif-ja";
  src: local("ＭＳ Ｐ明朝"), /* for IE */
      local("MS PMincho"), /* ＭＳ Ｐ明朝 */
      local("HiraMinProN-W3"), local("Hiragino Mincho ProN"), /* ヒラギノ明朝 ProN W3 */
      local("HiraMinPro-W3"), local("Hiragino Mincho Pro"), /* ヒラギノ明朝 Pro W3 */
      local("YuMin-Medium"), local("YuMincho"), /* 游明朝体(macOS) */
      local("Yu Mincho"), /* 游明朝(Windows) */
      local("BIZ UDPMincho"); /* BIZ UDP明朝 */
}

@font-face {
  font-family: "sans-serif-ja";
  src: local("ＭＳ Ｐゴシック"), /* for IE */
       local("MS PGothic"), /* ＭＳ Ｐゴシック */
       local("HiraginoSans-W3"), local("Hiragino Sans"), /* ヒラギノ角ゴシック */
       local("HiraKakuProN-W3"), local("Hiragino Kaku Gothic ProN"), /* ヒラギノ角ゴ ProN W3 */
       local("HiraKakuPro-W3"), local("Hiragino Kaku Gothic Pro"), /* ヒラギノ角ゴ Pro W3 */
       local("ヒラギノ角ゴ W3"), /* for old  Safari */
       local("HiraginoKaku-W3-90msp-RKSJ-H"), /* ヒラギノ角ゴ W3(TrueType) */
       local("YuGothic-Medium"), local("YuGothic"), /* 游ゴシック体(macOS) */
       local("Yu Gothic Medium"), local("Yu Gothic"), /* 游ゴシック(Windows) "Yu Gothic" is a fallback. */
       local("BIZ UDPGothic"); /* BIZ UDPゴシック */
}

/* 縦組み用 (vertical writing) */

@font-face {
  font-family: "serif-ja-v";
  src: local("ＭＳ 明朝"), /* for IE */
       local("MS Mincho"), /* ＭＳ 明朝 */
       local("HiraMinProN-W3"), local("Hiragino Mincho ProN"), /* ヒラギノ明朝 ProN W3 */
       local("HiraMinPro-W3"), local("Hiragino Mincho Pro"), /* ヒラギノ明朝 Pro W3 */
       local("YuMin-Medium"), local("YuMincho"), /* 游明朝体(macOS) */
       local("Yu Mincho"), /* 游明朝(Windows) */
       local("BIZ UDMincho"); /*  BIZ UD明朝 */
}

@font-face {
  font-family: "sans-serif-ja-v";
  src: local("ＭＳ ゴシック"), /* for IE */
       local("MS Gothic"), /* ＭＳ ゴシック */
       local("HiraginoSans-W3"), local("Hiragino Sans"), /* ヒラギノ角ゴシック */
       local("HiraKakuProN-W3"), local("Hiragino Kaku Gothic ProN"), /* ヒラギノ角ゴ ProN W3 */
       local("HiraKakuPro-W3"), local("Hiragino Kaku Gothic Pro"), /* ヒラギノ角ゴ Pro W3 */
       local("ヒラギノ角ゴ W3"), /* for old Safari */
       local("HiraKakuDS-W3-83pv-RKSJ-H"), /* ヒラギノ角ゴ W3(TrueType) */
       local("YuGothic-Medium"), local("YuGothic"), /* 游ゴシック体(macOS) */
       local("Yu Gothic Medium"), local("Yu Gothic"), /* 游ゴシック(Windows)  "Yu Gothic" is a fallback. */
       local("BIZ UDGothic"); /* BIZ UDゴシック */
}`;o.s(["default",()=>a])}]);